Personal Portfolio v2
last updated: November 5, 2013

This site is not a finished product. I will continue to work on it until I believe it is professional looking enough. All markup was written by me with the exception of jquery.js, holder.js, font-awesome.css and the background gradient that was from an online texture generator.

Future plans:
Responsive design
Add page source to new page with page previews
Repost link and page source for Food Inc. project
Add view buttons next to download buttons on main page
Recreate page with Wordpress or Drupal as CMS
Improve footer with better social media links
Add navigation beneath header image

I am working on a couple other projects as well at the moment.
1. Last year I made a quick flash sound board of some of the funny things professors have said in lecture. I lost it accidentally so I want to recreate it as an android application.
2. One of the projects for COMP2526 this year was John Conway's Game of Life. I want to recreate it as an android application.
3. A very simple application that increments a count every time a button is pushed.

There are three folders that I am hosting on my domain that are not linked to in my website:
brycendorsay.com/portfolio	- this is a bootstrap site that is fully responsive
brycendorsay.com/foodinc	- my team's winning website project for intro to web dev
brycendorsay.com/wordpress	- this is where I host my current wordpress experiment. The site currently at that address is trying to emulate the Google Play tablet UI look and feel

If you have any questions or would like to talk please email me at contact@brycendorsay.com or call at 1 250 937-7361.
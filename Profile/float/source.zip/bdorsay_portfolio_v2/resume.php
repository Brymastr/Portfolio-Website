<!-- TITLE -->
<?php include 'header.php'; ?>
<div id="content">
<iframe src="resume.pdf"
style="width:100%; height:100%;" frameborder="0"></iframe>
</div>
<!-- FOOTER -->
<?php include 'footer.php'?>
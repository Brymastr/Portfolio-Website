</div> <!-- CONTAINER CLOSE -->
	<div id="footer">

		<div class="footer-inner">
			<div class="categories">
				<h3><a href="projects.php">Projects</a></h3>
				<a href="food-inc.php">Food Inc.</a>
				<a href="auto-robot.php">NXT Robot</a>
			</div>
			<div class="categories">
				<h3><a href="ideas.php">Ideas</a></h3>
				<a>Albert Counter</a>
				<a>Professor Sound Board</a>
			</div>
			<div class="categories cat-wide">
				<h3><a href="#">Contact</a></h3>
				<div class="footer-contact">
					<p>Call me at: 1 250 937-7361</p>
					<p>Email me at: dorsay@live.ca</p>
				</div>
			</div>
			<div class="by-line">
				<div class="bordered"></div>
				<p>Designed and created by Brycen Dorsay</p>
				<ul>
					<li><a href="http://www.twitter.com/Brymastr" target="_blank"><i class="icon-twitter"></i></a></li>
					<li><a href="http://www.facebook.com/Brymastr" target="_blank"><i class="icon-facebook"></i></a></li>
					<li><a href="http://www.github.com/Brymastr" target="_blank"><i class="icon-github"></i></a></li>
					<li><a href="http://www.linkedin.com/in/brycen" target="_blank"><i class="icon-linkedin"></i></a></li>
				</ul>
			</div>
		</div>
	</div>
</body>
</html>
